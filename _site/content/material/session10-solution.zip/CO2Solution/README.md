
`R/make_co2_data.R` creates tidy data from the data you can download from:
[https://data.worldbank.org/indicator/EN.ATM.CO2E.PC](https://data.worldbank.org/indicator/EN.ATM.CO2E.PC) (last updated on April 22, 2024)

`R/make_co2_plot.R` takes the tidy data and produced a plot.
