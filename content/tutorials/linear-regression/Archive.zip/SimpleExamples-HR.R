# Business Regression Examples - Datasets and Visualizations
here::i_am("Regression/SimpleExamples-HR.R")
library(here)
library(ggplot2)
library(scales)
library(dplyr)
library(gridExtra)
library(icaeDesign)

# EXAMPLE 3: HR SALARY ANALYSIS===============================================

# Generate HR data
set.seed(42)
n_hr <- 180  # 180 employees

hr_data <- data.frame(
  employee_id = 1:n_hr,
  # Primary relationship: experience -> salary
  experience = round(runif(n_hr, 0, 20), 1),  # Years of experience
  # Third variable: education_level (creates omitted variable bias)
  education_level = sample(c("Bachelor", "Master", "PhD"), 
                           n_hr, replace = TRUE, 
                           prob = c(0.5, 0.4, 0.1))
) %>%
  mutate(
    # Education premium (omitted variable)
    education_premium = case_when(
      education_level == "Bachelor" ~ 0,
      education_level == "Master" ~ 8000,
      education_level == "PhD" ~ 18000
    ),
    # Salary influenced by BOTH experience AND education
    salary = 35000 +            # Base salary
      2800 * experience +       # Experience effect (main relationship)
      education_premium +       # Education effect (omitted variable)
      rnorm(n_hr, 0, 4000),     # Random noise
    # Round for realism
    salary = round(salary, 0),
    # Create education dummy for regression
    master_degree = ifelse(education_level == "Master", 1, 0),
    phd_degree = ifelse(education_level == "PhD", 1, 0)
  )

summary(hr_data)
write.csv(hr_data, here("Regression/hr_data.csv"), row.names = FALSE)

# Create scatter plot for HR
hr_plot <- ggplot(hr_data, aes(x = experience, y = salary)) +
  geom_point(size = 2.5, alpha = 0.6, color= get_euf_colors("blue")) +
  geom_smooth(
    method = "lm", se = FALSE, color =  get_euf_colors("red"), size = 1.2
    ) +
  labs(
    title = "HR Salary Analysis",
    x = "Years of Professional Experience",
    y = "Annual Salary (EUR)",
    caption = "Each point represents one employee"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10, color = "gray60"),
    axis.title = element_text(size = 11),
    panel.grid.minor = element_blank()
  ) +
  scale_y_continuous(labels = number_format(suffix = " EUR")) 
hr_plot

ggsave(
  filename = here("Regression/Regression-LecExpl-HR.pdf"), 
  width = 6, height = 4)

## Regressions---------
# Simple regressions (what is discussed in the lecture)
cat("\n=== SIMPLE REGRESSION RESULTS (Bivariate) ===\n")
cat("\n3. HR: Salary ~ Experience\n")
lm_hr_simple <- lm(salary ~ experience, data = hr_data)
print(summary(lm_hr_simple)$coefficients)
# Multiple regressions (for omitted variable bias demonstration in lab)
cat("\n\n=== MULTIPLE REGRESSION RESULTS (With Third Variable) ===\n")
cat("\n3. HR: Salary ~ Experience + Education\n")
lm_hr_multiple <- lm(salary ~ experience + master_degree + phd_degree, data = hr_data)
print(summary(lm_hr_multiple)$coefficients)

cat("\n\n=== OMITTED VARIABLE BIAS DEMONSTRATION ===\n")
cat("Simple regression coefficient (experience):", round(coef(lm_hr_simple)[2], 2), "\n")
cat("Multiple regression coefficient (experience):", round(coef(lm_hr_multiple)[2], 2), "\n")
cat("Bias:", round(coef(lm_hr_simple)[2] - coef(lm_hr_multiple)[2], 2), "\n")


# Create clean table for Keynote
keynote_table <- lm_hr_simple %>%
  tidy() %>%
  mutate(
    Variable = case_when(
      term == "(Intercept)" ~ "Intercept",
      term == "ad_spend" ~ "Ad Spend (EUR)",
      TRUE ~ term
    ),
    Coefficient = round(estimate, 2),
    `Std Error` = round(std.error, 2),
    `P-value` = case_when(
      p.value < 0.001 ~ "<0.001",
      p.value < 0.01 ~ "<0.01",
      p.value < 0.05 ~ "<0.05",
      TRUE ~ as.character(round(p.value, 3))
    )
  ) %>%
  select(Variable, Coefficient, `Std Error`, `P-value`)

# Add R-squared row
r_squared_row <- tibble(
  Variable = "R2",
  Coefficient = round(summary(lm_hr_simple)$r.squared, 3),
  `Std Error` = "—",
  `P-value` = "—"
)

keynote_table <- rbind(keynote_table, r_squared_row)
print(as.data.frame(keynote_table, row.names))
