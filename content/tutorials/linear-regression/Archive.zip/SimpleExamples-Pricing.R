# Business Regression Examples - Datasets and Visualizations
here::i_am("Regression/SimpleExamples-Pricing.R")
library(here)
library(ggplot2)
library(scales)
library(dplyr)
library(gridExtra)
library(icaeDesign)

# EXAMPLE 2: PRICING STRATEGY==================================================

# Generate pricing data
set.seed(42)
n_pricing <- 52  # Weekly data for 1 year

pricing_data <- data.frame(
  week = 1:n_pricing,
  # Primary relationship: price -> demand
  price = runif(n_pricing, 8, 25),  # Product price in EUR
  # Third variable: competitor_price (creates omitted variable bias)
  competitor_price = runif(n_pricing, 10, 30)  # Competitor price in EUR
) %>%
  mutate(
    # Demand influenced by BOTH own price AND competitor price
    # This creates omitted variable bias when competitor price is excluded
    demand = 800 +                 # Base demand
      -25 * price +                # Own price effect (main relationship)
      15 * competitor_price +      # Competitor price effect (omitted variable)
      rnorm(n_pricing, 0, 40),     # Random noise
    # Ensure positive demand
    demand = pmax(demand, 50),
    # Round for realism
    demand = round(demand, 0),
    price = round(price, 2),
    competitor_price = round(competitor_price, 2)
  )


summary(pricing_data)
write.csv(pricing_data, here("Regression/pricing_data.csv"), row.names = FALSE)

# Create scatter plot for pricing
pricing_plot <- ggplot(pricing_data, aes(x = price, y = demand)) +
  geom_point(size = 3, alpha = 0.7, color = get_euf_colors("blue")) +
  geom_smooth(
    method = "lm", se = FALSE, color = get_euf_colors("red"), size = 1.2
  ) +
  labs(
    title = "Pricing Strategy Analysis",
    x = "Product Price (EUR)",
    y = "Weekly Units Sold",
    caption = "Each point represents one week"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10, color = "gray60"),
    axis.title = element_text(size = 11),
    panel.grid.minor = element_blank()
  ) +
  scale_x_continuous(labels = number_format(suffix = " EUR")) 
pricing_plot

ggsave(
  filename = here("Regression/Regression-LecExpl-Pricing.pdf"), 
  width = 6, height = 4)

## Regressions---------
# Simple regressions (what is discussed in the lecture)
cat("\n=== SIMPLE REGRESSION RESULTS (Bivariate) ===\n")
cat("\n2. Pricing: Demand ~ Price\n")
lm_pricing_simple <- lm(demand ~ price, data = pricing_data)
print(summary(lm_pricing_simple)$coefficients)
# Multiple regressions (for omitted variable bias demonstration in lab)
cat("\n\n=== MULTIPLE REGRESSION RESULTS (With Third Variable) ===\n")
cat("\n2. Pricing: Demand ~ Price + Competitor Price\n")
lm_pricing_multiple <- lm(demand ~ price + competitor_price, data = pricing_data)
print(summary(lm_pricing_multiple)$coefficients)

cat("\n\n=== OMITTED VARIABLE BIAS DEMONSTRATION ===\n")
cat("Simple regression coefficient (price):", round(coef(lm_pricing_simple)[2], 2), "\n")
cat("Multiple regression coefficient (price):", round(coef(lm_pricing_multiple)[2], 2), "\n")
cat("Bias:", round(coef(lm_pricing_simple)[2] - coef(lm_pricing_multiple)[2], 2), "\n")

# Create clean table for Keynote
keynote_table <- lm_pricing_simple %>%
  tidy() %>%
  mutate(
    Variable = case_when(
      term == "(Intercept)" ~ "Intercept",
      term == "price" ~ "Price (EUR)",
      TRUE ~ term
    ),
    Coefficient = round(estimate, 2),
    `Std Error` = round(std.error, 2),
    `P-value` = case_when(
      p.value < 0.001 ~ "<0.001",
      p.value < 0.01 ~ "<0.01",
      p.value < 0.05 ~ "<0.05",
      TRUE ~ as.character(round(p.value, 3))
    )
  ) %>%
  select(Variable, Coefficient, `Std Error`, `P-value`)

# Add R-squared row
r_squared_row <- tibble(
  Variable = "R2",
  Coefficient = round(summary(lm_pricing_simple)$r.squared, 3),
  `Std Error` = "—",
  `P-value` = "—"
)

keynote_table <- rbind(keynote_table, r_squared_row)
print(as.data.frame(keynote_table, row.names))
