# Business Regression Examples - Datasets and Visualizations
here::i_am("Regression/SimpleExamples-Marketing.R")
library(here)
library(ggplot2)
library(scales)
library(dplyr)
library(gridExtra)
library(icaeDesign)
library(broom)

# EXAMPLE 1: MARKETING ROI ANALYSIS===========================================

# Generate marketing data
set.seed(42)
n_marketing <- 36  # 3 years of monthly data

marketing_data <- data.frame(
  month = 1:n_marketing,
  # Primary relationship: ad_spend -> sales
  ad_spend = runif(n_marketing, 2000, 15000),  # Monthly ad spend in EUR
  # Third variable: website_traffic (creates omitted variable bias)
  website_traffic = runif(n_marketing, 5000, 25000)  # Monthly unique visitors
) %>%
  mutate(
    # Sales influenced by BOTH ad spend AND website traffic
    # This creates omitted variable bias when traffic is excluded
    sales = 8000 +                 # Base sales
      2.8 * ad_spend +             # Ad spend effect (main relationship)
      0.4 * website_traffic +      # Website traffic effect (omitted variable)
      rnorm(n_marketing, 0, 3000), # Random noise
    sales = round(sales, 0), 
    ad_spend = round(ad_spend, 0),
    website_traffic = round(website_traffic, 0)
  )

summary(marketing_data)
write.csv(marketing_data, here("Regression/marketing_data.csv"), row.names = FALSE)


# Create scatter plot
marketing_plot <- ggplot(marketing_data, aes(x = ad_spend, y = sales)) +
  geom_point(size = 3, alpha = 0.7, color = get_euf_colors("blue")) +
  geom_smooth(
    method = "lm", se = FALSE, color = get_euf_colors("red"), size = 1.2
  ) +
  labs(
    title = "Marketing ROI Analysis",
    x = "Digital Advertising Spend (EUR)",
    y = "Online Sales Revenue (EUR)",
    caption = "Each point represents one month"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold"),
    plot.subtitle = element_text(size = 10, color = "gray60"),
    axis.title = element_text(size = 11),
    panel.grid.minor = element_blank()
  ) +
  scale_x_continuous(labels = number_format(scale = 0.001, suffix = "k EUR")) +
  scale_y_continuous(labels = number_format(scale = 0.001, suffix = "k EUR"))
marketing_plot

ggsave(
  filename = here("Regression/Regression-LecExpl-Marketing.pdf"), 
  width = 6, height = 4)

## Regressions---------
# Simple regressions (what is discussed in the lecture)
cat("\n=== SIMPLE REGRESSION RESULTS (Bivariate) ===\n")
cat("\n1. Marketing: Sales ~ Ad Spend\n")
lm_marketing_simple <- lm(sales ~ ad_spend, data = marketing_data)
print(summary(lm_marketing_simple)$coefficients)
# Multiple regressions (for omitted variable bias demonstration in lab)
cat("\n\n=== MULTIPLE REGRESSION RESULTS (With Third Variable) ===\n")
cat("\n1. Marketing: Sales ~ Ad Spend + Website Traffic\n")
lm_marketing_multiple <- lm(sales ~ ad_spend + website_traffic, data = marketing_data)
print(summary(lm_marketing_multiple)$coefficients)

cat("\n\n=== OMITTED VARIABLE BIAS DEMONSTRATION ===\n")
cat("Simple regression coefficient (ad_spend):", round(coef(lm_marketing_simple)[2], 2), "\n")
cat("Multiple regression coefficient (ad_spend):", round(coef(lm_marketing_multiple)[2], 2), "\n")
cat("Bias:", round(coef(lm_marketing_simple)[2] - coef(lm_marketing_multiple)[2], 2), "\n")

# Create clean table for Keynote
keynote_table <- lm_marketing_simple %>%
  tidy() %>%
  mutate(
    Variable = case_when(
      term == "(Intercept)" ~ "Intercept",
      term == "ad_spend" ~ "Ad Spend (EUR)",
      TRUE ~ term
    ),
    Coefficient = round(estimate, 2),
    `Std Error` = round(std.error, 2),
    `P-value` = case_when(
      p.value < 0.001 ~ "<0.001",
      p.value < 0.01 ~ "<0.01",
      p.value < 0.05 ~ "<0.05",
      TRUE ~ as.character(round(p.value, 3))
    )
  ) %>%
  select(Variable, Coefficient, `Std Error`, `P-value`)

# Add R-squared row
r_squared_row <- tibble(
  Variable = "R2",
  Coefficient = round(summary(lm_marketing_simple)$r.squared, 3),
  `Std Error` = "—",
  `P-value` = "—"
)

keynote_table <- rbind(keynote_table, r_squared_row)
print(as.data.frame(keynote_table, row.names))
